const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg);
const favicon = (url) => { try { return `https://www.google.com/s2/favicons?sz=32&domain=${new URL(url).hostname}`; } catch { return ""; } };
const host = (url) => { try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return url; } };

function show(id) { for (const s of ["loading", "signed-out", "signed-in"]) $(s).hidden = s !== id; }
function msg(el, text, isError = false) { el.textContent = text; el.classList.toggle("error", isError); }

let page = null;

async function loadSignedIn(user) {
  show("signed-in");
  $("who").textContent = user.email || "";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const info = await send({ type: "pageInfo", tab });
  page = info.page;
  if (page) {
    $("page-title").textContent = page.title || page.url;
    $("page-host").textContent = host(page.url);
    $("page-icon").src = favicon(page.url);
  } else {
    $("page-title").textContent = "This page can't be saved (browser or extension pages).";
    $("save-btn").disabled = true;
  }
  const cols = await send({ type: "collections" });
  for (const c of cols.collections || []) {
    const o = document.createElement("option");
    o.value = c.id; o.textContent = c.name;
    $("collection").appendChild(o);
  }
  loadRecent();
}

async function loadRecent() {
  const r = await send({ type: "recent", limit: 8 });
  const ul = $("recent");
  ul.replaceChildren();
  if (r.error) { ul.innerHTML = `<li class="empty"></li>`; ul.firstChild.textContent = r.error; return; }
  if (!r.items?.length) { ul.innerHTML = '<li class="empty">Nothing saved yet.</li>'; return; }
  for (const b of r.items) {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.href = b.url; a.target = "_blank"; a.rel = "noopener";
    const img = document.createElement("img"); img.src = favicon(b.url); img.width = 16; img.height = 16; img.alt = "";
    const span = document.createElement("span"); span.textContent = b.title || host(b.url);
    a.append(img, span); li.appendChild(a); ul.appendChild(li);
  }
}

$("login").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("login-btn").disabled = true;
  msg($("login-msg"), "");
  const r = await send({ type: "signIn", email: $("email").value, password: $("password").value });
  $("login-btn").disabled = false;
  if (r.error) return msg($("login-msg"), r.error, true);
  loadSignedIn(r.user);
});

$("forgot").addEventListener("click", async () => {
  const email = $("email").value.trim();
  if (!email) return msg($("login-msg"), "Type your email above first.", true);
  const r = await send({ type: "resetPassword", email });
  msg($("login-msg"), r.error || "Password reset email sent.", !!r.error);
});

$("save-btn").addEventListener("click", async () => {
  if (!page) return;
  $("save-btn").disabled = true;
  msg($("save-msg"), "Saving…");
  const r = await send({ type: "save", item: { ...page, collectionId: $("collection").value || null } });
  $("save-btn").disabled = false;
  if (r.status === "saved") { msg($("save-msg"), "Saved ✓ It's on your phone too."); loadRecent(); }
  else if (r.status === "exists") msg($("save-msg"), "Already saved.");
  else if (r.status === "invalid") msg($("save-msg"), "This page can't be saved.", true);
  else msg($("save-msg"), r.error || "Couldn't save.", true);
});

$("signout").addEventListener("click", async () => {
  await send({ type: "signOut" });
  show("signed-out");
});

(async () => {
  const r = await send({ type: "state" });
  if (r?.user) loadSignedIn(r.user); else show("signed-out");
})();
